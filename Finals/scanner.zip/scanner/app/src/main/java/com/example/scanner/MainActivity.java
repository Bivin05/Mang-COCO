package com.example.scanner;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.image.ImageProcessor;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.FileNotFoundException;
import java.nio.ByteBuffer;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_IMAGE_SELECT = 2;
    private static final int PERMISSION_REQUEST_CODE = 3;

    private ImageView imageView;
    private Button captureButton;
    private Button selectButton;

    private Bitmap selectedImage;
    private Classifier classifier;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        imageView = findViewById(R.id.imageView);
        captureButton = findViewById(R.id.captureButton);
        selectButton = findViewById(R.id.selectButton);

        // Load the pre-trained model (replace with your own model loading code)
        classifier = new Classifier();

        // Request camera and storage permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }

        // Capture button click event
        captureButton.setOnClickListener(v -> captureImage());

        // Select button click event
        selectButton.setOnClickListener(v -> selectImage());
    }

    private void captureImage() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_IMAGE_SELECT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            processImage(imageBitmap);
        } else if (requestCode == REQUEST_IMAGE_SELECT && resultCode == RESULT_OK) {
            Uri imageUri = data.getData();
            try {
                Bitmap imageBitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
                processImage(imageBitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void processImage(Bitmap imageBitmap) {
        // Display the selected image
        imageView.setImageBitmap(imageBitmap);

        // Preprocess the image
        TensorImage inputImage = loadImage(imageBitmap);
        ByteBuffer inputData = inputImage.getBuffer();

        // Perform inference
        Map<String, Float> predictions = classifier.classify(inputData);

        // Process the predictions and calculate the area of affection
        float areaOfAffection = processPredictions(predictions);

        // Display the result
        String resultMessage = "Area of affection: " + areaOfAffection + " square meters";
        Toast.makeText(this, resultMessage, Toast.LENGTH_SHORT).show();
    }

    private float processPredictions(Map<String, Float> predictions) {
        // Process the predictions, calculate the area of affection, and return the result
        // You need to implement this part based on your model's output and your specific calculations

        return 0; // Replace with your own area calculation
    }

    private TensorImage loadImage(Bitmap bitmap) {
        // Create a TensorImage object and preprocess the bitmap
        TensorImage tensorImage = TensorImage.fromBitmap(bitmap);
        tensorImage = normalizeImage(tensorImage);

        return tensorImage;
    }

    private TensorImage normalizeImage(TensorImage tensorImage) {
        TensorBuffer tensorBuffer = tensorImage.getTensorBuffer();
        DataType dataType = ((TensorBuffer) tensorBuffer).getDataType();

        if (dataType == DataType.FLOAT32) {
            float[] imageData = tensorBuffer.getFloatArray();
            normalizeFloatArray(imageData);
        } else if (dataType == DataType.UINT8) {
            byte[] imageData = tensorBuffer.getBuffer().array();
            normalizeByteArray(imageData);
        }

        return tensorImage;
    }

    private void normalizeFloatArray(float[] array) {
        // Normalize the array by dividing each element by 255.0f
        for (int i = 0; i < array.length; i++) {
            array[i] /= 255.0f;
        }
    }

    private void normalizeByteArray(byte[] array) {
        // Normalize the array by converting each byte to an unsigned value and dividing it by 255.0f
        for (int i = 0; i < array.length; i++) {
            array[i] = (byte) ((array[i] & 0xFF) / 255.0f);
        }
    }


}
